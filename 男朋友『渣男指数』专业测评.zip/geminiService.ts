
import { GoogleGenAI } from "@google/genai";
import { Question } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export async function generateRelationshipAnalysis(
  scorePercentage: number,
  answers: { questionId: number; selectedOptionLabel: string }[],
  questions: Question[]
): Promise<{ analysis: string; recommendation: string }> {
  const model = "gemini-3-flash-preview";
  
  const summaryPrompt = `
    作为一名资深的恋爱心理学专家，请根据以下测评数据为用户提供一份精准、专业的『男朋友渣男指数』测评报告。
    
    测评得分（危险系数）：${scorePercentage}% (分数越高代表行为越“渣”)
    
    用户具体的回答摘要：
    ${answers.map(a => {
      const q = questions.find(item => item.id === a.questionId);
      return `- 问题: ${q?.text}, 选择: ${a.selectedOptionLabel}`;
    }).join('\n')}

    请输出一个JSON格式的回复：
    {
      "analysis": "一段约200字的深度心理学剖析，语气要专业、同理心强，指出这段关系中的核心风险点。",
      "recommendation": "具体的行动建议，分为『继续观察』、『设定底线』或『及时止损』三个维度给出建议。"
    }
    注意：不要使用Markdown，直接返回JSON字符串。
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: summaryPrompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const result = JSON.parse(response.text || '{}');
    return {
      analysis: result.analysis || "分析生成失败，请结合得分自行判断。",
      recommendation: result.recommendation || "建议审视你们之间的信任基础。"
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    return {
      analysis: "系统分析由于流量过大暂时离线，但根据你的得分为 " + scorePercentage + "%，建议提高警惕。",
      recommendation: "保持独立思考，不要过度依赖对方的承诺。"
    };
  }
}
