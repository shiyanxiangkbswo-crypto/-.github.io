
import { Question } from './types';

export const QUESTIONS: Question[] = [
  {
    id: 1,
    text: "他是否有过『断联』或突然失踪的行为？",
    category: 'trust',
    options: [
      { label: "从未有过，回消息很及时", score: 0, weight: 1 },
      { label: "偶尔忙起来会几个小时不回，事后会解释", score: 2, weight: 1 },
      { label: "经常发生，且理由总是含糊其辞", score: 8, weight: 1.5 },
      { label: "动不动就冷暴力，甚至玩失踪几天", score: 10, weight: 2 }
    ]
  },
  {
    id: 2,
    text: "他的社交圈（朋友圈、动态）里是否有你的存在？",
    category: 'boundaries',
    options: [
      { label: "大方公开，大家都知道我们的关系", score: 0, weight: 1 },
      { label: "发过几张含蓄的照片（Soft Launch）", score: 3, weight: 1 },
      { label: "从未发过任何关于我的内容", score: 7, weight: 1.5 },
      { label: "屏蔽我发针对别人的内容，甚至对外称单身", score: 10, weight: 2 }
    ]
  },
  {
    id: 3,
    text: "当你们发生矛盾时，他通常的表现是？",
    category: 'manipulation',
    options: [
      { label: "积极沟通，主动解决问题", score: 0, weight: 1.2 },
      { label: "逃避沟通，等我冷静", score: 5, weight: 1 },
      { label: "都是我的错，开始翻旧账（Gaslighting）", score: 9, weight: 1.8 },
      { label: "威胁分手或语言暴力", score: 10, weight: 2 }
    ]
  },
  {
    id: 4,
    text: "关于财务支出（约会、礼物等），他的态度是？",
    category: 'effort',
    options: [
      { label: "大方且愿意为我花钱，不在意计较", score: 0, weight: 1 },
      { label: "礼尚往来，追求基本平衡", score: 1, weight: 1 },
      { label: "嘴上说爱我，实际很少主动买单", score: 8, weight: 1.5 },
      { label: "精细算计，甚至让我倒贴钱", score: 10, weight: 2 }
    ]
  },
  {
    id: 5,
    text: "他对『前任』或异性朋友的态度是？",
    category: 'boundaries',
    options: [
      { label: "边界清晰，不保持无意义联系", score: 0, weight: 1.5 },
      { label: "有联系，但公开透明", score: 3, weight: 1 },
      { label: "私下联系，手机从不离手且设密码", score: 9, weight: 1.8 },
      { label: "养鱼达人，暧昧对象不断", score: 10, weight: 2 }
    ]
  },
  {
    id: 6,
    text: "他是否经常给你画大饼（许下诺言却不兑现）？",
    category: 'future',
    options: [
      { label: "言出必行，说到的都做到了", score: 0, weight: 1 },
      { label: "偶尔因为不可抗力忘记，会补救", score: 3, weight: 1 },
      { label: "承诺很多，兑现很少", score: 8, weight: 1.5 },
      { label: "全是虚假繁荣，只会打嘴炮", score: 10, weight: 2 }
    ]
  },
  {
    id: 7,
    text: "在生活中，他是否会尊重你的意见和个人空间？",
    category: 'manipulation',
    options: [
      { label: "完全尊重，支持我的独立性", score: 0, weight: 1 },
      { label: "偶尔有掌控欲，但可以商量", score: 4, weight: 1 },
      { label: "否定我的价值观，试图改造我", score: 8, weight: 1.8 },
      { label: "极度控制，甚至干涉我的社交和职业", score: 10, weight: 2 }
    ]
  },
  {
    id: 8,
    text: "当他面对诱惑或困难时，责任感表现如何？",
    category: 'trust',
    options: [
      { label: "非常有担当，值得信赖", score: 0, weight: 1.5 },
      { label: "比较犹豫，但最终会选择正确的一方", score: 4, weight: 1 },
      { label: "遇事推卸责任，甚至甩锅给我", score: 8, weight: 1.5 },
      { label: "极度自私，只考虑自己的利益", score: 10, weight: 2 }
    ]
  },
  {
    id: 9,
    text: "你生病或遇到低谷期时，他的反应是？",
    category: 'effort',
    options: [
      { label: "悉心照顾，提供极高的情绪价值", score: 0, weight: 1.2 },
      { label: "会关心，但实际行动不多", score: 4, weight: 1 },
      { label: "敷衍两句“多喝热水”，然后继续打游戏", score: 8, weight: 1.5 },
      { label: "嫌你烦，觉得你破坏了他的心情", score: 10, weight: 2 }
    ]
  },
  {
    id: 10,
    text: "他是否带你见过他的家人或核心朋友圈？",
    category: 'future',
    options: [
      { label: "正式引荐，把我规划进他的生活", score: 0, weight: 1 },
      { label: "见过朋友，但没见过家人", score: 3, weight: 1 },
      { label: "总是以“时机未到”为由藏着掖着", score: 8, weight: 1.5 },
      { label: "完全处于“地下情”状态，拒绝任何社交渗透", score: 10, weight: 2 }
    ]
  },
  {
    id: 11,
    text: "对于手机的隐私边界，他的做法是？",
    category: 'trust',
    options: [
      { label: "坦坦荡荡，甚至主动录我的指纹", score: 0, weight: 1 },
      { label: "有个人空间，但从不刻意遮掩", score: 2, weight: 1 },
      { label: "手机不离身，洗澡都要带着", score: 8, weight: 1.8 },
      { label: "我看一眼就会大发雷霆，极度敏感", score: 10, weight: 2 }
    ]
  },
  {
    id: 12,
    text: "他的朋友们评价他通常是怎样的？",
    category: 'boundaries',
    options: [
      { label: "靠谱、专一，大家都觉得他遇到了对的人", score: 0, weight: 1 },
      { label: "比较爱玩，但对女朋友还行", score: 4, weight: 1 },
      { label: "朋友里有很多爱玩的“海王”，甚至互相掩护", score: 9, weight: 1.8 },
      { label: "他朋友圈里的人经常拿他开低俗的暧昧玩笑", score: 10, weight: 2 }
    ]
  },
  {
    id: 13,
    text: "当你们讨论到未来规划时，他的反应是？",
    category: 'future',
    options: [
      { label: "有清晰的共同目标，并为之努力", score: 0, weight: 1.2 },
      { label: "愿意讨论，但目前还没谱", score: 4, weight: 1 },
      { label: "顾左右而言他，从不正面回应", score: 8, weight: 1.5 },
      { label: "明确表示不想负责，甚至崇尚“不婚不育”只图乐", score: 10, weight: 2 }
    ]
  },
  {
    id: 14,
    text: "他是否会在外人面前贬低你或拿你开玩笑？",
    category: 'manipulation',
    options: [
      { label: "非常护着我，给我足够的体面", score: 0, weight: 1.2 },
      { label: "偶尔会开点玩笑，但有分寸", score: 3, weight: 1 },
      { label: "喜欢通过贬低我来衬托他的优越感", score: 9, weight: 1.8 },
      { label: "当众羞辱，甚至事后说是我想多了", score: 10, weight: 2 }
    ]
  },
  {
    id: 15,
    text: "对于两性亲密关系的尊重程度如何？",
    category: 'boundaries',
    options: [
      { label: "非常尊重我的意愿，从未强迫", score: 0, weight: 1.5 },
      { label: "会商量着来，尊重我的节奏", score: 2, weight: 1 },
      { label: "目的性极强，不满足就变脸", score: 9, weight: 1.8 },
      { label: "完全不尊重隐私，甚至有偷拍或传播的倾向", score: 10, weight: 2.5 }
    ]
  }
];
