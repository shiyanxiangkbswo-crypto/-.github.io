
export interface Question {
  id: number;
  text: string;
  category: 'trust' | 'effort' | 'boundaries' | 'manipulation' | 'future';
  options: Option[];
}

export interface Option {
  label: string;
  score: number; // 0 to 10, higher means more 'red flags'
  weight: number;
}

export interface QuizResult {
  totalScore: number;
  maxPossibleScore: number;
  percentage: number;
  analysis: string;
  riskLevel: 'Safe' | 'Warning' | 'Danger' | 'Critical';
  recommendation: string;
}

export enum AppState {
  Lobby = 'LOBBY',
  Quiz = 'QUIZ',
  Analyzing = 'ANALYZING',
  Result = 'RESULT'
}
