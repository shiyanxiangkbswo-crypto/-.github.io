
import React, { useState, useEffect, useCallback } from 'react';
import { QUESTIONS } from './constants';
import { AppState, QuizResult } from './types';
import { generateRelationshipAnalysis } from './geminiService';
import { 
  ShieldCheck, 
  AlertTriangle, 
  Flame, 
  ChevronRight, 
  ArrowLeft, 
  Share2, 
  RotateCcw,
  Heart,
  ExternalLink,
  Target
} from 'lucide-react';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(AppState.Lobby);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<{ questionId: number; score: number; weight: number; label: string }[]>([]);
  const [result, setResult] = useState<QuizResult | null>(null);
  const [loadingText, setLoadingText] = useState('AI 正在深度剖析样本行为...');

  const startQuiz = () => {
    setState(AppState.Quiz);
    setCurrentQuestionIndex(0);
    setUserAnswers([]);
  };

  const handleOptionSelect = (option: { label: string; score: number; weight: number }) => {
    const newAnswers = [...userAnswers, { 
      questionId: QUESTIONS[currentQuestionIndex].id, 
      score: option.score, 
      weight: option.weight,
      label: option.label
    }];
    setUserAnswers(newAnswers);

    if (currentQuestionIndex < QUESTIONS.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      processResults(newAnswers);
    }
  };

  const processResults = async (answers: typeof userAnswers) => {
    setState(AppState.Analyzing);
    
    // Calculate Score
    let totalScore = 0;
    let maxPossibleScore = 0;
    answers.forEach(a => {
      totalScore += a.score * a.weight;
      maxPossibleScore += 10 * a.weight;
    });

    const percentage = Math.round((totalScore / maxPossibleScore) * 100);
    
    // AI Analysis
    const aiData = await generateRelationshipAnalysis(
      percentage, 
      answers.map(a => ({ questionId: a.questionId, selectedOptionLabel: a.label })),
      QUESTIONS
    );

    let riskLevel: QuizResult['riskLevel'] = 'Safe';
    if (percentage > 30) riskLevel = 'Warning';
    if (percentage > 60) riskLevel = 'Danger';
    if (percentage > 85) riskLevel = 'Critical';

    setResult({
      totalScore,
      maxPossibleScore,
      percentage,
      analysis: aiData.analysis,
      recommendation: aiData.recommendation,
      riskLevel
    });

    setState(AppState.Result);
  };

  useEffect(() => {
    if (state === AppState.Analyzing) {
      const texts = [
        "检索社交行为模式...",
        "分析话术真实度...",
        "对比海王行为数据库...",
        "多维评估信任价值...",
        "深度解析潜意识动机...",
        "生成心理学避雷报告..."
      ];
      let i = 0;
      const interval = setInterval(() => {
        setLoadingText(texts[i % texts.length]);
        i++;
      }, 1200);
      return () => clearInterval(interval);
    }
  }, [state]);

  const reset = () => {
    setState(AppState.Lobby);
    setResult(null);
  };

  // Views
  const LobbyView = () => (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-6 text-center animate-fadeIn">
      <div className="w-24 h-24 bg-pink-500 rounded-full flex items-center justify-center mb-8 shadow-xl shadow-pink-200 animate-pulse">
        <ShieldCheck className="text-white w-12 h-12" />
      </div>
      <h1 className="text-4xl font-extrabold text-slate-800 mb-4 tracking-tight leading-tight">
        男朋友『渣男指数』<br/><span className="text-pink-600">15维度专业测评</span>
      </h1>
      <p className="text-slate-500 text-lg mb-10 max-w-sm leading-relaxed">
        基于15项核心行为指标，深度解析恋爱风险。<br/>
        由 AI 实验室提供逻辑支持。
      </p>
      
      <div className="grid grid-cols-2 gap-4 w-full max-w-sm mb-12">
        <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
          <p className="text-xs text-slate-400 font-semibold uppercase mb-1">题量</p>
          <p className="text-slate-700 font-medium">15道核心题</p>
        </div>
        <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
          <p className="text-xs text-slate-400 font-semibold uppercase mb-1">耗时</p>
          <p className="text-slate-700 font-medium">约3分钟</p>
        </div>
      </div>

      <button 
        onClick={startQuiz}
        className="w-full max-w-sm bg-slate-900 hover:bg-slate-800 text-white font-bold py-5 rounded-full shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-2"
      >
        开启深度测评
        <ChevronRight className="w-5 h-5" />
      </button>
      <p className="mt-6 text-xs text-slate-400 font-medium italic">已有超过 20 万+ 用户完成测评并获得建议</p>
    </div>
  );

  const QuizView = () => {
    const question = QUESTIONS[currentQuestionIndex];
    const progress = ((currentQuestionIndex) / QUESTIONS.length) * 100;

    return (
      <div className="p-6 max-w-2xl mx-auto min-h-screen flex flex-col justify-center animate-slideIn">
        <div className="mb-10">
          <div className="flex justify-between items-end mb-4">
            <span className="text-slate-400 font-semibold text-sm">测评进度 {currentQuestionIndex + 1}/{QUESTIONS.length}</span>
            <span className="text-pink-500 font-bold text-lg">{Math.round(progress)}%</span>
          </div>
          <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-pink-500 transition-all duration-500" 
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-50">
          <div className="mb-2 text-xs font-bold text-pink-500 uppercase tracking-widest">
            {question.category === 'trust' ? '信任机制' : 
             question.category === 'boundaries' ? '社交边界' : 
             question.category === 'manipulation' ? '情感操控' : 
             question.category === 'effort' ? '投入度' : '未来规划'}
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-8 leading-snug">
            {question.text}
          </h2>

          <div className="space-y-4">
            {question.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleOptionSelect(opt)}
                className="w-full p-5 text-left bg-white border-2 border-slate-100 rounded-2xl hover:border-pink-500 hover:bg-pink-50 transition-all flex items-center group"
              >
                <div className="w-8 h-8 rounded-xl border border-slate-200 flex items-center justify-center mr-4 group-hover:bg-pink-500 group-hover:text-white transition-colors text-slate-400 font-bold">
                  {String.fromCharCode(65 + idx)}
                </div>
                <span className="flex-1 text-slate-700 font-medium">{opt.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const AnalyzingView = () => (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-6 text-center">
      <div className="relative w-32 h-32 mb-10">
        <div className="absolute inset-0 bg-pink-100 rounded-full animate-ping opacity-30"></div>
        <div className="relative w-full h-full bg-white rounded-full flex items-center justify-center shadow-lg border-4 border-pink-500 animate-bounce">
           <Target className="text-pink-500 w-16 h-16" />
        </div>
      </div>
      <h3 className="text-2xl font-bold text-slate-800 mb-3">{loadingText}</h3>
      <p className="text-slate-400 text-sm max-w-[240px]">AI 正在处理 15 个维度的加权数据，请稍候...</p>
    </div>
  );

  const ResultView = () => {
    if (!result) return null;

    const riskColor = {
      Safe: 'text-green-600 bg-green-50 border-green-100',
      Warning: 'text-yellow-600 bg-yellow-50 border-yellow-100',
      Danger: 'text-orange-600 bg-orange-50 border-orange-100',
      Critical: 'text-red-600 bg-red-50 border-red-100'
    }[result.riskLevel];

    const riskIcon = {
      Safe: <ShieldCheck className="w-8 h-8" />,
      Warning: <AlertTriangle className="w-8 h-8" />,
      Danger: <Flame className="w-8 h-8" />,
      Critical: <Flame className="w-8 h-8" />
    }[result.riskLevel];

    return (
      <div className="p-6 max-w-2xl mx-auto pb-24 animate-fadeIn">
        <div className="bg-white rounded-[2.5rem] p-8 shadow-2xl border border-slate-50 mb-8 overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-green-400 via-yellow-400 to-red-500 opacity-20"></div>
          
          <div className="text-center mb-10">
            <h2 className="text-slate-400 text-xs font-black uppercase tracking-[0.3em] mb-4">15维度专业测评报告</h2>
            <div className="relative inline-flex items-center justify-center w-40 h-40">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="80"
                  cy="80"
                  r="70"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="transparent"
                  className="text-slate-100"
                />
                <circle
                  cx="80"
                  cy="80"
                  r="70"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="transparent"
                  strokeDasharray={440}
                  strokeDashoffset={440 - (440 * result.percentage) / 100}
                  className={`${result.percentage > 60 ? 'text-red-500' : 'text-pink-500'} transition-all duration-1000 ease-out`}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-5xl font-black text-slate-900">{result.percentage}</span>
                <span className="text-xs font-bold text-slate-400 uppercase">危险指数</span>
              </div>
            </div>
          </div>

          <div className={`p-6 rounded-3xl flex items-center gap-4 mb-10 border ${riskColor}`}>
            <div className="shrink-0">{riskIcon}</div>
            <div>
              <p className="font-bold text-lg">AI 诊断：{
                result.riskLevel === 'Safe' ? '恋爱模范（值得信赖）' : 
                result.riskLevel === 'Warning' ? '黄灯亮起（多加观察）' : 
                result.riskLevel === 'Danger' ? '渣男行为显著（高度危险）' : '核心重灾区（建议断联）'
              }</p>
              <p className="text-sm opacity-90 leading-snug mt-1">
                基于15道客观行为数据点，模型判定的加权得分为 {result.percentage}/100。
              </p>
            </div>
          </div>

          <div className="space-y-8">
            <section>
              <h3 className="flex items-center gap-2 text-slate-800 font-bold text-lg mb-3">
                <span className="w-1.5 h-6 bg-pink-500 rounded-full"></span>
                行为深度逻辑剖析
              </h3>
              <p className="text-slate-600 leading-relaxed text-justify bg-slate-50 p-6 rounded-2xl border border-slate-100 whitespace-pre-wrap">
                {result.analysis}
              </p>
            </section>

            <section>
              <h3 className="flex items-center gap-2 text-slate-800 font-bold text-lg mb-3">
                <span className="w-1.5 h-6 bg-slate-900 rounded-full"></span>
                专家级行动策略
              </h3>
              <div className="text-slate-600 leading-relaxed bg-slate-900 text-white p-6 rounded-2xl shadow-xl">
                {result.recommendation}
              </div>
            </section>
          </div>

          <div className="mt-12 pt-8 border-t border-slate-100 text-center">
            <div className="flex justify-center gap-2 mb-4">
               {[...Array(5)].map((_, i) => (
                 <div key={i} className={`w-2 h-2 rounded-full ${i < (100 - result.percentage)/20 ? 'bg-green-400' : 'bg-slate-200'}`}></div>
               ))}
            </div>
            <p className="text-slate-400 text-[10px] leading-relaxed max-w-xs mx-auto">
              此报告由 RedFlag Detector AI 实验室生成。本工具旨在提高女性在亲密关系中的风险意识，测评结果受主观填答影响，仅供参考。
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={() => window.print()}
            className="bg-white border-2 border-slate-100 text-slate-700 font-bold py-4 rounded-2xl flex items-center justify-center gap-2 shadow-sm hover:bg-slate-50 active:scale-95 transition-all"
          >
            <Share2 className="w-5 h-5" />
            保存报告
          </button>
          <button 
            onClick={reset}
            className="bg-slate-900 text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-2 shadow-lg hover:bg-slate-800 active:scale-95 transition-all"
          >
            <RotateCcw className="w-5 h-5" />
            重新测评
          </button>
        </div>
        
        <div className="mt-8 text-center">
          <p className="text-slate-400 text-sm mb-2">觉得有用？分享给闺蜜</p>
          <div className="flex justify-center gap-4">
             <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 hover:text-pink-500 cursor-pointer transition-colors">
                <Heart className="w-5 h-5" />
             </div>
             <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 hover:text-blue-500 cursor-pointer transition-colors">
                <ExternalLink className="w-5 h-5" />
             </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#fafafa] selection:bg-pink-100">
      <header className="sticky top-0 z-10 bg-[#fafafa]/80 backdrop-blur-md px-6 py-4 flex justify-between items-center border-b border-slate-100">
        <div className="flex items-center gap-2 font-bold text-slate-900">
          <div className="w-8 h-8 bg-pink-500 rounded-lg flex items-center justify-center shadow-lg shadow-pink-200">
            <ShieldCheck className="text-white w-5 h-5" />
          </div>
          <span className="hidden sm:inline">RedFlag Detector <span className="text-[10px] bg-slate-100 px-1.5 py-0.5 rounded ml-1 font-black">PRO</span></span>
        </div>
        {state === AppState.Quiz && (
          <button onClick={reset} className="text-slate-400 hover:text-slate-600 flex items-center gap-1 text-sm font-bold">
             <ArrowLeft className="w-5 h-5" />
             <span>退出</span>
          </button>
        )}
        <div className="text-[10px] text-slate-300 font-mono">v1.2.0-LATEST</div>
      </header>

      <main className="container mx-auto max-w-4xl min-h-[calc(100vh-64px)]">
        {state === AppState.Lobby && <LobbyView />}
        {state === AppState.Quiz && <QuizView />}
        {state === AppState.Analyzing && <AnalyzingView />}
        {state === AppState.Result && <ResultView />}
      </main>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(20px); }
          to { opacity: 1; transform: translateX(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.6s ease-out forwards;
        }
        .animate-slideIn {
          animation: slideIn 0.4s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default App;
